package com.example.fragmentexample.ui.main

import android.app.Activity.RESULT_OK
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.fragmentexample.R
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.form_fragment.*
import kotlinx.android.synthetic.main.main_fragment.*
import kotlinx.android.synthetic.main.main_fragment.btn_ajouter
import androidx.core.app.ActivityCompat.startActivityForResult

import android.content.Intent
import android.graphics.Bitmap
import java.lang.Exception
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.test.core.app.ApplicationProvider.getApplicationContext

import android.provider.MediaStore
import androidx.test.core.app.ApplicationProvider
import com.bumptech.glide.Glide
import com.example.fragmentexample.Model.Planet
import com.github.guilhe.sharedprefsutils.ktx.get
import com.github.guilhe.sharedprefsutils.ktx.put
import java.io.IOException


class FormFragment: Fragment() {
    companion object {
        fun newInstance() = FormFragment()
    }

    //var names = mutableListOf<String>()
    //var images = mutableListOf<String>()
    //var planet_description = mutableListOf<String>()
    private lateinit var viewModel: MainViewModel
    lateinit var prefs: SharedPreferences
    lateinit var selectedImage : String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        return inflater.inflate(R.layout.form_fragment, container, false)
    }

    private fun saveData(planets : MutableList<Planet>) {
        prefs = requireActivity().getSharedPreferences("test", Context.MODE_PRIVATE)
        //prefs.put("name", names)
        //prefs.put("image", images)
        //prefs.put("description", planet_description)
        prefs.put("planet", planets)

        /*val sharedPreferences = requireActivity().getSharedPreferences("shared preferences", AppCompatActivity.MODE_PRIVATE)

        val editor = sharedPreferences.edit()
        val gson_names = Gson()
        val json_name = gson_names.toJson(names)
        val gson_image = Gson()
        val json_image = gson_image.toJson(images)
        val gson_description = Gson()
        val json_description = gson_description.toJson(planet_description)
        editor.putString("name", json_name)
        editor.putString("image", json_image)
        editor.putString("description", json_description)
        editor.apply()*/
    }

    /*private fun loadNames() : MutableList<String>{
        prefs = requireActivity().getSharedPreferences("test", Context.MODE_PRIVATE)
        return prefs.get("name", object : TypeToken<MutableList<String>>() {}, mutableListOf())
    }*/

    /*private fun loadImages() : MutableList<String>{
        prefs = requireActivity().getSharedPreferences("test", Context.MODE_PRIVATE)
        return prefs.get("image", object : TypeToken<MutableList<String>>() {}, mutableListOf())
    }*/

    /*private fun loadDescriptions() : MutableList<String>{
        prefs = requireActivity().getSharedPreferences("test", Context.MODE_PRIVATE)
        return prefs.get("description", object : TypeToken<MutableList<String>>() {}, mutableListOf())
    }*/

    private fun loadPlanets() : MutableList<Planet> {
        prefs = requireActivity().getSharedPreferences("test", Context.MODE_PRIVATE)
        return prefs.get("planet", object : TypeToken<MutableList<Planet>>() {}, mutableListOf())
    }
    /*private fun loadData() {
        prefs = requireActivity().getSharedPreferences("test", Context.MODE_PRIVATE)
        names = prefs.get("name", object : TypeToken<MutableList<String>>() {}, mutableListOf())
        images = prefs.get("image", object : TypeToken<MutableList<String>>() {}, mutableListOf())
        planet_description = prefs.get("description", object : TypeToken<MutableList<String>>() {}, mutableListOf())


        /*val sharedPreferences = requireActivity().getSharedPreferences("shared preferences", AppCompatActivity.MODE_PRIVATE)
        val gson = Gson()
        val json_name = sharedPreferences.getString("name", "")
        val json_image = sharedPreferences.getString("image", "")
        val json_description = sharedPreferences.getString("description", "")
        val type = object: TypeToken<MutableList<String>>() {
        }.type

        if(json_name == null)
            names = mutableListOf()
        else {
            names = gson.fromJson(json_name, type)

        }
        if(json_image == null)
            images = mutableListOf()
        else
            images = gson.fromJson(json_image, type)

        if(json_description == null)
            planet_description = mutableListOf()
        else
            planet_description = gson.fromJson(json_description, type)*/

    }*/

    private fun buttonClicked(){
        btn_add_planet.setOnClickListener {
            if(planet_name.text.toString().isNotEmpty() && description.text.toString().isNotEmpty() && ::selectedImage.isInitialized) {
                /*var names = loadNames()
            names.add(planet_name.text.toString())
            var images = loadImages()
            images.add(selectedImage)
            var planet_description = loadDescriptions()
            planet_description.add(description.text.toString())
            */
                var planets = loadPlanets()
                planets.add(
                    Planet(
                        planet_name.text.toString(),
                        description.text.toString(),
                        selectedImage,
                        constante_g.text.toString().toDouble()
                    )
                )

                saveData(planets)

                var fr = getFragmentManager()?.beginTransaction()
                fr?.replace(R.id.container, MainFragment())
                fr?.commit()
            }

            else{
                warningLabel.text = "Attention ! Il vous manque des informations."
            }
        }
    }

    private fun buttonAddClicked(){
        btn_add_image.setOnClickListener {
            val intent = Intent()
            intent.type = "image/*"
            intent.action = Intent.ACTION_GET_CONTENT //
            startActivityForResult(Intent.createChooser(intent, "Select File"), 1);        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        buttonAddClicked()
        buttonClicked()
    }

    /*protected fun onActivityResult(requestCode: Int, resultCode: Int, @Nullable data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            try {
                this.imgUri = data.data
                val photo = data.extras!!["data"] as Bitmap?
                imgView.setImageBitmap(photo)
            } catch (e: Exception) {
            }
        }
    }*/

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            selectedImage = data?.getData().toString()
            Glide.with(this).load(selectedImage).into(imgForm)
        }
    }
}