package com.example.fragmentexample.Model

import java.lang.Math.round
import kotlin.math.roundToInt

class Planet(private val name: String, private val description: String, private val image_uri: String, private val constante_g: Double){
    fun getName() : String {
        return name
    }

    fun getDescription() : String {
        return description
    }

    fun getImageUri() : String {
        return image_uri
    }

    override fun toString(): String {
        if (name != "Terre")
            return description+"\n\nSi vous utilisez une fusée Saturne 5 (la fusée la plus puissante jamais conçu), il faudra consommer "+ ((94200 * constante_g) / 0.35).roundToInt() +"L de carburant pour quitter "+name+"."
        return description+"\n\nPour quitter la terre, il vous faudra 94200L de carburant."
    }
}