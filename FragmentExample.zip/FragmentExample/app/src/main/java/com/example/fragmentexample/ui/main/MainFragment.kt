package com.example.fragmentexample.ui.main

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.example.fragmentexample.Model.Planet
import com.example.fragmentexample.R
import com.github.guilhe.sharedprefsutils.ktx.get
import com.github.guilhe.sharedprefsutils.ktx.put
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.main_fragment.*
import android.widget.RelativeLayout

//import android.R
import kotlinx.android.synthetic.main.form_fragment.*


class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    //var names = arrayOf("Terre","Mercure", "Vénus", "Mars", "Jupiter", "Saturne", "Uranus", "Neptune")
    //var images = arrayOf("drawable/earth", "drawable/mercure", "drawable/venus", "drawable/mars", "drawable/jupiter", "drawable/saturne", "drawable/uranus", "drawable/neptune")
    //var planet_description = arrayOf("terre", "mercure", "venus", "mars", "jupiter", "saturne", "uranus", "neptune")

    //var planets = mutableListOf<Planet>(Planet("Terre", "terre", "drawable/earth", 0.35), Planet("Mercure", "mercure", "drawable/mercure", 0.378),Planet("Vénus", "vénus", "drawable/venus", 0.905),Planet("Mars", "mars", "drawable/mars", 0.371),Planet("Jupiter", "jupiter", "drawable/jupiter", 2.358),Planet("Saturne", "saturne", "drawable/saturne", 1.064),Planet("Uranus", "uranus", "drawable/uranus", 0.904), Planet("Neptune", "neptune", "drawable/neptune", 1.14))
    var planets = mutableListOf<Planet>()
    //var names = mutableListOf<String>()
    //var images = mutableListOf<String>()
    //var planet_description = mutableListOf<String>()
    lateinit var prefs: SharedPreferences

    var current_Page : Int = 0


    private lateinit var viewModel: MainViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        loadData()
        return inflater.inflate(R.layout.main_fragment, container, false)
    }

    private fun buttonClicked(){
        btn_ajouter.setOnClickListener {
            var fr = getFragmentManager()?.beginTransaction()
            fr?.replace(R.id.container, FormFragment())
            fr?.commit()
        }
    }

    private fun directionClicked(){
        btn_right.setOnClickListener {

            if (current_Page<planets.size-1)
                current_Page+=1

            headerLabel.text = planets[current_Page].getName()
            txtMain.text = planets[current_Page].toString()

            if(current_Page<8){

                val uri = planets[current_Page].getImageUri()
                val imageResource = resources.getIdentifier(uri, null, requireActivity().packageName)
                var imageview = imgMain as ImageView
                val res = resources.getDrawable(imageResource)
                imageview.setImageDrawable(res)
            }
            else if (current_Page<planets.size){
                Glide.with(this).load(Uri.parse(planets[current_Page].getImageUri())).into(imgMain)
            }
            else{
                    var fr = getFragmentManager()?.beginTransaction()
                    fr?.replace(R.id.container, FormFragment())
                    fr?.commit()
            }
        }

        btn_left.setOnClickListener {

            if (current_Page>0)
                current_Page-=1

            headerLabel.text = planets[current_Page].getName()
            txtMain.text = planets[current_Page].toString()

            if(current_Page<8){

                val uri = planets[current_Page].getImageUri()
                val imageResource = resources.getIdentifier(uri, null, requireActivity().packageName)
                var imageview = imgMain as ImageView
                val res = resources.getDrawable(imageResource)
                imageview.setImageDrawable(res)
            }
            else if (current_Page<planets.size){
                Glide.with(this).load(Uri.parse(planets[current_Page].getImageUri())).into(imgMain)
            }
            else{
                var fr = getFragmentManager()?.beginTransaction()
                fr?.replace(R.id.container, FormFragment())
                fr?.commit()
            }
        }
    }




    private fun saveData() {
        prefs = requireActivity().getSharedPreferences("test", Context.MODE_PRIVATE)
        /*prefs.put("name", names)
        prefs.put("image", images)
        prefs.put("description", planet_description)*/
        prefs.put("planet", planets)
    }

    private fun loadData() {
        prefs = requireActivity().getSharedPreferences("test", Context.MODE_PRIVATE)
        //names =  prefs.get("name", object : TypeToken<MutableList<String>>() {}, mutableListOf())
        //images = prefs.get("image", object : TypeToken<MutableList<String>>() {}, mutableListOf())
        //planet_description = prefs.get("description", object : TypeToken<MutableList<String>>() {}, mutableListOf())
        planets = prefs.get("planet", object : TypeToken<MutableList<Planet>>() {}, mutableListOf())

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        // TODO: Use the ViewModel
        directionClicked()
        /*main.setOnClickListener {
            var str = ""
            for (img in planet_description){
                str+= img+"\t"
            }
            headerLabel.text = str

        }*/
        buttonClicked()

    }

}